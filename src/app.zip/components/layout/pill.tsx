import type { ReactNode } from "react";

type PillProps = {
  children: ReactNode;
};

export function Pill({ children }: PillProps) {
  return (
    <span className="bg-muted text-muted-foreground rounded-full border px-3 py-1 text-xs font-medium">
      {children}
    </span>
  );
}
